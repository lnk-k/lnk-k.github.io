# C++ 容器实现与 GoogleTest 测试

按照题目要求，用 **C++17** 实现动态数组、双向链表、栈、队列、二叉搜索树、B 树和 B+ 树，提供完整 CMake 工程、演示程序及 GoogleTest 测试。

## 1. 项目结构

```text
cpp-containers/
├── CMakeLists.txt
├── README.md
├── include/containers/
│   ├── containers.hpp           # 统一入口
│   ├── dynamic_array.hpp        # 动态数组
│   ├── linked_list.hpp          # 双向链表
│   ├── stack_queue.hpp          # 栈与队列
│   ├── binary_search_tree.hpp   # 二叉搜索树
│   ├── b_tree.hpp               # B 树
│   └── b_plus_tree.hpp          # B+ 树
├── src/main.cpp                # 七种容器的演示
├── tests/
│   ├── linear_tests.cpp
│   └── tree_tests.cpp
└── third_party/
    ├── googletest-1.15.2.tar.gz  # 官方 GoogleTest 源码包
    └── LICENSE.googletest
```

模板类的定义和实现放在头文件中，便于编译器针对不同类型实例化。`containers` 是可被其他程序链接的 CMake INTERFACE 库；`containers_demo` 和 `containers_tests` 是两个可执行目标。

## 2. 构建与运行

环境要求：CMake 3.16 或更高版本、支持 C++17 的 GCC / Clang / MSVC，以及对应的构建工具（Make、Ninja 或 Visual Studio）。

在解压后的项目根目录执行：

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug
cmake --build build --config Debug --parallel
ctest --test-dir build -C Debug --output-on-failure
```

以上 `ctest --test-dir` 用法要求 CMake 3.20+；使用 CMake 3.16～3.19 时，进入 `build` 目录运行 `ctest -C Debug --output-on-failure`。

macOS / Linux 运行演示：

```bash
./build/containers_demo
```

Windows 使用 Visual Studio 生成器时：

```powershell
.\build\Debug\containers_demo.exe
```

预期输出：

```text
DynamicArray: 20 30
LinkedList: 10 30
Stack pop order: 20 10
Queue dequeue order: 10 20
BST: 10 20 30 40 60 70 80
BTree: 10 20 30 40 60 70 80
BPlusTree: 10 20 30 40 60 70 80
BPlusTree range [25, 65]: 30 40 60
All trees valid: true
```

GoogleTest 优先从系统查找（版本 1.15+）；没有安装时，CMake 使用 `third_party` 内附的官方 v1.15.2 源码压缩包，因此完整交付包可以**离线构建测试**。压缩包通过 SHA-256 校验。如果手动删除了该压缩包，CMake 才回退到在线下载。

只构建演示程序：

```bash
cmake -S . -B build-demo -DBUILD_TESTING=OFF
cmake --build build-demo --parallel
```

Clang / GCC 下可启用内存与未定义行为检查：

```bash
cmake -S . -B build-asan -DCMAKE_BUILD_TYPE=Debug -DCONTAINERS_ENABLE_SANITIZERS=ON
cmake --build build-asan --parallel
ctest --test-dir build-asan --output-on-failure
```

## 3. 与 Java 容器的关系及约定

| 本项目 | Java 中的参考概念 | 存储方式 |
|---|---|---|
| `DynamicArray<T>` | `ArrayList<E>` | 分配原始连续存储，容量不足时倍增 |
| `LinkedList<T>` | `LinkedList<E>` | 手写双向链表 |
| `Stack<T>` | `Deque<E>` 的栈操作 | 复用本项目动态数组，后进先出 |
| `Queue<T>` | `Queue<E>` / `LinkedList<E>` | 复用本项目链表，先进先出 |
| `BinarySearchTree<T>` | 有序集合的查找、插入、删除语义 | 非平衡二叉搜索树 |
| `BTree<T, t>` | 有序集合语义 | 多路平衡搜索树 |
| `BPlusTree<T, t>` | 有序集合及范围查询语义 | 内部索引结点 + 双向连接的叶子 |

Java 标准库的 `TreeSet` / `TreeMap` 基于红黑树，并非本项目的普通 BST、B 树或 B+ 树；Java 标准集合库也没有直接对应 B 树和 B+ 树的容器类。

- 索引从 0 开始。`insert(index, value)` 允许 `index == size()`，其他按索引访问要求 `index < size()`。
- 越界访问、空容器出栈/出队、空树求最小值/最大值，抛出 `std::out_of_range`。
- 动态数组的 `operator[]` 不检查边界；需要检查时用 `at()`。
- 数组、链表、栈、队列允许重复元素；三种树是**不重复键的集合**，`insert` 返回是否实际插入，`erase` 返回是否实际删除。三种树不实现键值映射。
- 三种树默认使用 `std::less<T>`，支持指定无状态比较器。相等由 `!cmp(a,b) && !cmp(b,a)` 判定，不要求键实现 `operator==`。
- `min()` / `max()` 及输出顺序遵循比较器；使用 `std::greater<int>` 时，`min()` 是数值最大的键。
- `BPlusTree::range_query(low, high)` 返回闭区间，包含两端，按比较器顺序排列；反向区间返回空结果。
- 数组和链表实现深拷贝、移动和析构；栈和队列继承底层容器的这些行为。三种树禁用拷贝及移动，避免无意复制拥有结点的结构。
- 树中键需要可拷贝、可移动和可赋值；数组和链表也可存储 `std::unique_ptr` 这样的仅移动类型（不能对此类实例调用复制操作）。
- `values()`、`range_query()` 返回独立的 `std::vector<T>` 结果副本。树的结点也用 `std::vector` 存放局部键及孩子指针，但查找、分裂、借位、合并和再平衡算法均自行实现，没有使用 `std::set` / `std::map` 代替树。
- 树修改、数组扩容/移动、删除元素可能使此前返回的引用失效；调用者不应跨这些操作保留引用。

## 4. 基本操作

所有容器均有 `size()`、`empty()`、`clear()`。

| 容器 | 额外接口 |
|---|---|
| 动态数组 | `capacity()`、`reserve(n)`、`push_back(v)`、`pop_back()`、`insert(i,v)`、`erase(i)`、`at(i)`、`operator[](i)`、`back()` |
| 双向链表 | `push_front(v)`、`push_back(v)`、`pop_front()`、`pop_back()`、`insert(i,v)`、`erase(i)`、`remove(v)`、`at(i)`、`front()`、`back()`、`values()` |
| 栈 | `push(v)`、`pop()`、`top()` |
| 队列 | `enqueue(v)`、`dequeue()`、`front()`、`back()` |
| 三种树 | `insert(k)`、`erase(k)`、`contains(k)`、`min()`、`max()`、`values()`、`validate()` |
| B+ 树 | 额外提供 `range_query(low,high)` |

`LinkedList::remove(v)` 删除第一个匹配元素。`pop()` / `dequeue()` 等删除操作不返回元素，可先调用 `top()` / `front()` 再删除。

使用示例：

```cpp
#include "containers/containers.hpp"
#include <iostream>

int main() {
    containers::BPlusTree<int, 2> tree;
    for (int x : {40, 10, 30, 20, 50}) tree.insert(x);
    tree.erase(30);
    for (int x : tree.range_query(15, 45)) std::cout << x << ' ';
    // 输出：20 40
}
```

## 5. 核心算法

### 动态数组、链表、栈和队列

动态数组通过 `std::allocator` 分配原始存储，只构造实际存在的元素。容量满时扩容为原来的两倍，再搬迁元素；任意位置插入、删除通过移动后续元素完成。`clear()` 析构元素但保留容量。

双向链表维护 `head`、`tail`、`prev` 和 `next`。按下标查找时，根据位置从表头或表尾遍历。空表与单结点表的首尾指针同步维护。

栈在数组尾部插入和删除；队列在链表尾部入队、头部出队。

### 二叉搜索树

小于结点键的元素放在左子树，大于结点键的元素放在右子树。查找和插入沿比较结果向下走。

删除分为无孩子、一个孩子、两个孩子三种情况。两个孩子时，将右子树最小结点取出并接替被删除结点。`values()` 使用中序遍历。`clear()` 迭代释放结点，避免退化树在析构时产生很深的递归。

### B 树

模板参数 `t` 为**最小度数**，不是“最大孩子数”：每个非根结点含 `t-1` 到 `2t-1` 个键；内部结点有“键数 + 1”个孩子，即 `t` 到 `2t` 个。非空根至少一个键；所有叶子深度相同。

插入前检查要进入的孩子是否已满。满结点分成左右两个结点，中间键提升到父结点；根满时建立新根。

删除内部键时优先用前驱或后继替换。如果左右孩子都只有最少键，则将两个孩子和父分隔键合并。向下删除前保证目标孩子至少有 `t` 个键：先向有富余键的兄弟借位，否则合并。根被删空时用唯一孩子替代根。

### B+ 树

实际数据键全部位于叶子，内部键只是导航用的分隔键，`keys[i]` 等于第 `i+1` 棵子树的最小键。**等于分隔键时进入右边孩子**，因此内部查找使用 `upper_bound`。

叶子容量上限是 `2t-1` 个键，非根叶子下限为 `t-1` 个键；内部结点最多 `2t` 个孩子，非根内部结点至少 `t` 个孩子。此处直接明确容量规则，避免不同教材对“阶”的定义差异。

插入溢出时分裂结点，叶子分裂还需维护双向叶子链；内部结点溢出会逐层向上传播。删除后若低于下限，先尝试向左右兄弟借键或孩子，否则合并。沿返回路径更新父分隔键，必要时收缩根。范围查询先定位起始叶子，再沿 `next` 扫描。

`validate()` 检查有序性、子树边界、结点容量、孩子数量、总键数和所有叶子等深。B+ 树还检查分隔键等于右子树最小键，以及叶子链表前后链接与树中叶子顺序一致。

## 6. 时间复杂度与实现范围

记元素数为 `n`，树高为 `h`，最小度数为 `t`，范围查询返回数为 `k`。以下不计算用户定义键的比较和拷贝成本。

| 操作 | 时间复杂度 |
|---|---|
| 数组随机访问 | O(1) |
| 数组尾部添加 / 栈入栈 | 均摊 O(1)，扩容时 O(n) |
| 数组中间插入、删除 | O(n) |
| 链表头尾操作 / 队列入队出队 | O(1) |
| 链表按下标访问、插入、删除 | O(n)，定位后修改指针 O(1) |
| BST 查找、插入、删除 | O(h)，平衡形态 O(log n)，最坏 O(n) |
| B 树 / B+ 树查找 | O(h log t)，h = O(log_t n) |
| B 树插入、删除 | O(t h) |
| 本项目 B+ 树插入、删除 | O(t h²) 的保守上界 |
| B+ 树范围查询 | O(h log t + k)，固定 t 时成立 |
| 三种树完整遍历 | O(n) |

B+ 树为突出教学可读性，修改后通过向下寻找各孩子的最小叶子键来重建分隔键，没有缓存子树最小键，因此更新的保守上界为 O(t h²)。这不是生产数据库的页缓存或磁盘索引实现。

项目聚焦题目中的基本操作，不实现迭代器、线程同步、磁盘持久化或完整 STL/Java API。BST 的中序遍历和结构校验使用递归，极端退化树会有较大的调用栈。树的修改操作不承诺在内存分配失败或用户类型拷贝/比较抛异常时维持原状；教学测试使用整数、字符串及无异常比较器。

## 7. 测试内容

- 线性容器：空容器和越界、扩容、首尾及中间插入删除、别名参数、深拷贝、移动、非默认构造元素的生命周期、仅移动元素。
- 栈和队列：后进先出、先进先出、空操作异常，以及与 `std::deque` 的随机对照。
- 三种树：重复键、不存在键删除、不同删除形态、清空后复用、最小/最大值。
- B 树和 B+ 树：分别使用 `t=2/3/8`，顺序、逆序、乱序删除以检查分裂、借位、合并、根收缩后的正确性。
- 随机对照：树操作与 `std::set` 比较，每次操作后核对结构、大小和完整遍历结果；每种树配置使用三个固定随机种子，每个种子 3000 次操作。
- B+ 树：跨叶子范围、闭区间边界、空区间、删除后的叶子链以及 4000 次随机更新后的范围查询。
- 泛型：字符串键、自定义降序比较器。

随机种子固定，可以复现失败；测试错误会报告种子、操作步骤或删除键。GoogleTest 参数化测试会为每一种树配置单独生成测试条目。

第三方 GoogleTest 保留其原始 BSD-3-Clause 许可证，见 `third_party/LICENSE.googletest`。
