# 编译与测试记录

验证日期：2026-09-22。

## 验证环境

- 系统：macOS。
- 编译器：AppleClang 21.0.0.21000099。
- CMake：3.31.6。
- C++ 标准：C++17。
- GoogleTest：1.15.2，使用项目内附的官方源码包。
- 构建类型：Debug。
- 检查选项：`-Wall -Wextra -Wpedantic`、AddressSanitizer、UndefinedBehaviorSanitizer。

## 结果

最终构建成功，项目代码未产生编译警告。CTest 运行结果：

```text
100% tests passed, 0 tests failed out of 53
Total Test time (real) = 2.25 sec
```

测试运行期间 AddressSanitizer 和 UndefinedBehaviorSanitizer 未报告错误。

| 测试组 | 用例数 |
|---|---:|
| 数组、链表、栈、队列及对象生命周期 | 10 |
| 三种树：7 种配置 × 5 个通用用例 | 35 |
| B+ 树范围查询：3 种度数 × 2 个用例 | 6 |
| 字符串键、降序比较器 | 2 |
| 合计 | 53 |

树的随机测试共执行 7 × 3 × 3000 = 63000 次操作，并在每一步后核对结构和标准库参考结果。B+ 树额外执行 3 × 4000 = 12000 次随机更新及范围查询；数组、链表、栈队列的随机测试另执行 13000 次操作。

演示程序成功运行，输出与 README 中的示例一致，最后一行是 `All trees valid: true`。

## 复现

在项目根目录执行：

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Debug -DCONTAINERS_ENABLE_SANITIZERS=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure -j 4
./build/containers_demo
```

测试使用固定随机种子，结果可复现；运行时间取决于机器。以上实际验证仅覆盖 macOS / AppleClang，未声称在 Windows 或 Linux 上实测。
