#pragma once
#include <algorithm>
#include <cstddef>
#include <functional>
#include <iterator>
#include <memory>
#include <stdexcept>
#include <utility>
#include <vector>

namespace containers {
// 数据只在叶子；内部 keys[i] 始终等于 children[i+1] 子树的最小键。
// 叶子最多 2t-1 个键，非根至少 t-1 个；内部结点最多 2t 个孩子，非根至少 t 个。
template <typename T, std::size_t MinDegree = 2, typename Compare = std::less<T>>
class BPlusTree {
    static_assert(MinDegree >= 2, "BPlusTree minimum degree must be >= 2");
    struct Node {
        bool leaf;
        std::vector<T> keys;
        std::vector<std::unique_ptr<Node>> children;
        Node* prev = nullptr; // 非拥有型指针，仅叶子使用。
        Node* next = nullptr;
        explicit Node(bool is_leaf) : leaf(is_leaf) {}
    };
    std::unique_ptr<Node> root_;
    std::size_t size_ = 0;
    Compare less_{};
    bool equal(const T& a, const T& b) const { return !less_(a, b) && !less_(b, a); }
    std::size_t lower(const Node& n, const T& key) const {
        return static_cast<std::size_t>(std::lower_bound(n.keys.begin(), n.keys.end(), key, less_) - n.keys.begin());
    }
    std::size_t child_index(const Node& n, const T& key) const {
        return static_cast<std::size_t>(std::upper_bound(n.keys.begin(), n.keys.end(), key, less_) - n.keys.begin());
    }
    const Node* first_leaf(const Node* n) const {
        while (n && !n->leaf) n = n->children.front().get();
        return n;
    }
    const T& minimum(const Node& n) const { return first_leaf(&n)->keys.front(); }
    void refresh(Node& n) {
        if (n.leaf) return;
        n.keys.clear();
        for (std::size_t i = 1; i < n.children.size(); ++i) n.keys.push_back(minimum(*n.children[i]));
    }
    const Node* find_leaf(const T& key) const {
        const Node* n = root_.get();
        while (n && !n->leaf) n = n->children[child_index(*n, key)].get();
        return n;
    }
    // 溢出时返回新右兄弟，让上一层接纳；否则返回 nullptr。
    std::unique_ptr<Node> insert_into(Node& n, const T& key) {
        if (n.leaf) {
            n.keys.insert(n.keys.begin() + lower(n, key), key);
            if (n.keys.size() <= 2 * MinDegree - 1) return nullptr;
            auto right = std::make_unique<Node>(true);
            right->keys.assign(n.keys.begin() + MinDegree, n.keys.end());
            n.keys.erase(n.keys.begin() + MinDegree, n.keys.end());
            right->next = n.next; right->prev = &n;
            if (n.next) n.next->prev = right.get();
            n.next = right.get();
            return right;
        }
        auto i = child_index(n, key);
        auto right_child = insert_into(*n.children[i], key);
        if (right_child) n.children.insert(n.children.begin() + i + 1, std::move(right_child));
        refresh(n);
        if (n.children.size() <= 2 * MinDegree) return nullptr;
        auto right = std::make_unique<Node>(false);
        const auto split = MinDegree + 1;
        for (std::size_t j = split; j < n.children.size(); ++j) right->children.push_back(std::move(n.children[j]));
        n.children.resize(split);
        refresh(n); refresh(*right);
        return right;
    }
    std::size_t occupancy(const Node& n) const { return n.leaf ? n.keys.size() : n.children.size(); }
    std::size_t minimum_occupancy(const Node& n) const { return n.leaf ? MinDegree - 1 : MinDegree; }
    void merge(Node& p, std::size_t left_index) {
        Node& left = *p.children[left_index];
        auto right = std::move(p.children[left_index + 1]);
        if (left.leaf) {
            left.keys.insert(left.keys.end(), std::make_move_iterator(right->keys.begin()), std::make_move_iterator(right->keys.end()));
            left.next = right->next;
            if (left.next) left.next->prev = &left;
        } else {
            for (auto& c : right->children) left.children.push_back(std::move(c));
            refresh(left);
        }
        p.children.erase(p.children.begin() + left_index + 1);
    }
    void rebalance(Node& p, std::size_t i) {
        Node& n = *p.children[i];
        if (occupancy(n) >= minimum_occupancy(n)) return;
        if (i && occupancy(*p.children[i - 1]) > minimum_occupancy(n)) {
            Node& left = *p.children[i - 1];
            if (n.leaf) {
                n.keys.insert(n.keys.begin(), std::move(left.keys.back())); left.keys.pop_back();
            } else {
                n.children.insert(n.children.begin(), std::move(left.children.back())); left.children.pop_back();
                refresh(left); refresh(n);
            }
        } else if (i + 1 < p.children.size() && occupancy(*p.children[i + 1]) > minimum_occupancy(n)) {
            Node& right = *p.children[i + 1];
            if (n.leaf) {
                n.keys.push_back(std::move(right.keys.front())); right.keys.erase(right.keys.begin());
            } else {
                n.children.push_back(std::move(right.children.front())); right.children.erase(right.children.begin());
                refresh(right); refresh(n);
            }
        } else if (i) merge(p, i - 1);
        else merge(p, i);
    }
    void erase_existing(Node& n, const T& key) {
        if (n.leaf) { n.keys.erase(n.keys.begin() + lower(n, key)); return; }
        auto i = child_index(n, key);
        erase_existing(*n.children[i], key);
        rebalance(n, i);
        refresh(n);
    }
    bool check(const Node& n, bool root, const T* low, const T* high, std::size_t depth,
               std::size_t& leaf_depth, std::size_t& count, std::vector<const Node*>& leaves) const {
        const auto occupied = occupancy(n);
        const auto min_allowed = root ? (n.leaf ? 1u : 2u) : minimum_occupancy(n);
        const auto max_allowed = n.leaf ? 2 * MinDegree - 1 : 2 * MinDegree;
        if (occupied < min_allowed || occupied > max_allowed) return false;
        for (std::size_t i = 0; i < n.keys.size(); ++i) {
            if ((i && !less_(n.keys[i - 1], n.keys[i])) || (low && less_(n.keys[i], *low)) ||
                (high && !less_(n.keys[i], *high))) return false;
        }
        if (n.leaf) {
            if (leaf_depth == 0) leaf_depth = depth;
            count += n.keys.size(); leaves.push_back(&n);
            return n.children.empty() && leaf_depth == depth;
        }
        if (n.children.size() != n.keys.size() + 1 || n.prev || n.next) return false;
        for (std::size_t i = 0; i < n.children.size(); ++i) {
            if (!n.children[i] || !check(*n.children[i], false, i ? &n.keys[i - 1] : low,
                i < n.keys.size() ? &n.keys[i] : high, depth + 1, leaf_depth, count, leaves)) return false;
            if (i && !equal(n.keys[i - 1], minimum(*n.children[i]))) return false;
        }
        return true;
    }
public:
    BPlusTree() = default;
    BPlusTree(const BPlusTree&) = delete;
    BPlusTree& operator=(const BPlusTree&) = delete;
    bool empty() const noexcept { return size_ == 0; }
    std::size_t size() const noexcept { return size_; }
    bool contains(const T& key) const {
        auto n = find_leaf(key);
        if (!n) return false;
        const auto i = lower(*n, key);
        return i < n->keys.size() && equal(n->keys[i], key);
    }
    bool insert(const T& key) {
        if (contains(key)) return false;
        if (!root_) root_ = std::make_unique<Node>(true);
        auto right = insert_into(*root_, key);
        if (right) {
            auto next = std::make_unique<Node>(false);
            next->children.push_back(std::move(root_)); next->children.push_back(std::move(right));
            refresh(*next); root_ = std::move(next);
        }
        ++size_; return true;
    }
    bool erase(const T& key) {
        if (!contains(key)) return false;
        T saved = key;
        erase_existing(*root_, saved); --size_;
        if (!root_->leaf && root_->children.size() == 1) {
            auto old = std::move(root_); root_ = std::move(old->children.front());
        }
        if (size_ == 0) root_.reset();
        return true;
    }
    const T& min() const {
        if (!root_) throw std::out_of_range("BPlusTree::min");
        return minimum(*root_);
    }
    const T& max() const {
        if (!root_) throw std::out_of_range("BPlusTree::max");
        const Node* n = root_.get(); while (!n->leaf) n = n->children.back().get(); return n->keys.back();
    }
    std::vector<T> values() const {
        std::vector<T> result; result.reserve(size_);
        for (auto n = first_leaf(root_.get()); n; n = n->next) result.insert(result.end(), n->keys.begin(), n->keys.end());
        return result;
    }
    // 包含两端；边界顺序由 Compare 定义。
    std::vector<T> range_query(const T& low, const T& high) const {
        std::vector<T> result;
        if (less_(high, low)) return result;
        auto n = find_leaf(low);
        auto i = n ? lower(*n, low) : 0;
        while (n) {
            for (; i < n->keys.size(); ++i) {
                if (less_(high, n->keys[i])) return result;
                result.push_back(n->keys[i]);
            }
            n = n->next; i = 0;
        }
        return result;
    }
    bool validate() const {
        if (!root_) return size_ == 0;
        std::size_t depth = 0, count = 0;
        std::vector<const Node*> leaves;
        if (!check(*root_, true, nullptr, nullptr, 1, depth, count, leaves) || count != size_) return false;
        for (std::size_t i = 0; i < leaves.size(); ++i) {
            if (leaves[i]->prev != (i ? leaves[i - 1] : nullptr) ||
                leaves[i]->next != (i + 1 < leaves.size() ? leaves[i + 1] : nullptr)) return false;
            if (i && !less_(leaves[i - 1]->keys.back(), leaves[i]->keys.front())) return false;
        }
        return true;
    }
    void clear() noexcept { root_.reset(); size_ = 0; }
};
} // namespace containers
