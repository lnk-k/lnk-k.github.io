#pragma once
#include <algorithm>
#include <cstddef>
#include <functional>
#include <iterator>
#include <memory>
#include <stdexcept>
#include <utility>
#include <vector>

namespace containers {
// 最小度数 t：非根结点 t-1 ... 2t-1 个键；内部结点有 keys+1 个孩子。
template <typename T, std::size_t MinDegree = 2, typename Compare = std::less<T>>
class BTree {
    static_assert(MinDegree >= 2, "BTree minimum degree must be >= 2");
    struct Node {
        bool leaf;
        std::vector<T> keys;
        std::vector<std::unique_ptr<Node>> children;
        explicit Node(bool is_leaf) : leaf(is_leaf) {}
    };
    std::unique_ptr<Node> root_;
    std::size_t size_ = 0;
    Compare less_{};
    bool equal(const T& a, const T& b) const { return !less_(a, b) && !less_(b, a); }
    std::size_t lower(const Node& n, const T& key) const {
        return static_cast<std::size_t>(std::lower_bound(n.keys.begin(), n.keys.end(), key, less_) - n.keys.begin());
    }
    void split_child(Node& parent, std::size_t i) {
        Node& left = *parent.children[i];
        auto right = std::make_unique<Node>(left.leaf);
        T median = left.keys[MinDegree - 1];
        right->keys.assign(left.keys.begin() + MinDegree, left.keys.end());
        left.keys.erase(left.keys.begin() + MinDegree - 1, left.keys.end());
        if (!left.leaf) {
            for (std::size_t j = MinDegree; j < left.children.size(); ++j)
                right->children.push_back(std::move(left.children[j]));
            left.children.resize(MinDegree);
        }
        parent.keys.insert(parent.keys.begin() + i, std::move(median));
        parent.children.insert(parent.children.begin() + i + 1, std::move(right));
    }
    void insert_nonfull(Node& n, const T& key) {
        auto i = lower(n, key);
        if (n.leaf) { n.keys.insert(n.keys.begin() + i, key); return; }
        if (n.children[i]->keys.size() == 2 * MinDegree - 1) {
            split_child(n, i);
            if (less_(n.keys[i], key)) ++i;
        }
        insert_nonfull(*n.children[i], key);
    }
    // 将父结点分隔键下移，合并 children[i] 和 children[i+1]。
    void merge(Node& parent, std::size_t i) {
        Node& left = *parent.children[i];
        auto right = std::move(parent.children[i + 1]);
        left.keys.push_back(std::move(parent.keys[i]));
        left.keys.insert(left.keys.end(), std::make_move_iterator(right->keys.begin()), std::make_move_iterator(right->keys.end()));
        for (auto& c : right->children) left.children.push_back(std::move(c));
        parent.keys.erase(parent.keys.begin() + i);
        parent.children.erase(parent.children.begin() + i + 1);
    }
    void borrow_left(Node& p, std::size_t i) {
        Node& n = *p.children[i]; Node& left = *p.children[i - 1];
        n.keys.insert(n.keys.begin(), std::move(p.keys[i - 1]));
        p.keys[i - 1] = std::move(left.keys.back()); left.keys.pop_back();
        if (!n.leaf) {
            n.children.insert(n.children.begin(), std::move(left.children.back())); left.children.pop_back();
        }
    }
    void borrow_right(Node& p, std::size_t i) {
        Node& n = *p.children[i]; Node& right = *p.children[i + 1];
        n.keys.push_back(std::move(p.keys[i]));
        p.keys[i] = std::move(right.keys.front()); right.keys.erase(right.keys.begin());
        if (!n.leaf) {
            n.children.push_back(std::move(right.children.front())); right.children.erase(right.children.begin());
        }
    }
    void erase_existing(Node& n, const T& key) {
        auto i = lower(n, key);
        if (i < n.keys.size() && equal(n.keys[i], key)) {
            if (n.leaf) { n.keys.erase(n.keys.begin() + i); return; }
            if (n.children[i]->keys.size() >= MinDegree) {
                Node* p = n.children[i].get();
                while (!p->leaf) p = p->children.back().get();
                T replacement = p->keys.back();
                n.keys[i] = replacement; erase_existing(*n.children[i], replacement);
            } else if (n.children[i + 1]->keys.size() >= MinDegree) {
                Node* p = n.children[i + 1].get();
                while (!p->leaf) p = p->children.front().get();
                T replacement = p->keys.front();
                n.keys[i] = replacement; erase_existing(*n.children[i + 1], replacement);
            } else { merge(n, i); erase_existing(*n.children[i], key); }
            return;
        }
        if (n.children[i]->keys.size() == MinDegree - 1) {
            if (i > 0 && n.children[i - 1]->keys.size() >= MinDegree) borrow_left(n, i);
            else if (i + 1 < n.children.size() && n.children[i + 1]->keys.size() >= MinDegree) borrow_right(n, i);
            else if (i + 1 < n.children.size()) merge(n, i);
            else { merge(n, i - 1); --i; }
        }
        erase_existing(*n.children[i], key);
    }
    void traverse(const Node& n, std::vector<T>& out) const {
        for (std::size_t i = 0; i < n.keys.size(); ++i) {
            if (!n.leaf) traverse(*n.children[i], out);
            out.push_back(n.keys[i]);
        }
        if (!n.leaf) traverse(*n.children.back(), out);
    }
    bool check(const Node& n, bool root, const T* low, const T* high,
               std::size_t depth, std::size_t& leaf_depth, std::size_t& count) const {
        if (n.keys.size() > 2 * MinDegree - 1 || n.keys.size() < (root ? 1 : MinDegree - 1)) return false;
        for (std::size_t i = 0; i < n.keys.size(); ++i) {
            if ((i && !less_(n.keys[i - 1], n.keys[i])) || (low && !less_(*low, n.keys[i])) ||
                (high && !less_(n.keys[i], *high))) return false;
        }
        count += n.keys.size();
        if (n.leaf) {
            if (leaf_depth == 0) leaf_depth = depth;
            return n.children.empty() && leaf_depth == depth;
        }
        if (n.children.size() != n.keys.size() + 1) return false;
        for (std::size_t i = 0; i < n.children.size(); ++i)
            if (!n.children[i] || !check(*n.children[i], false, i ? &n.keys[i - 1] : low,
                i < n.keys.size() ? &n.keys[i] : high, depth + 1, leaf_depth, count)) return false;
        return true;
    }
public:
    BTree() = default;
    BTree(const BTree&) = delete;
    BTree& operator=(const BTree&) = delete;
    bool empty() const noexcept { return size_ == 0; }
    std::size_t size() const noexcept { return size_; }
    bool contains(const T& key) const {
        const Node* n = root_.get();
        while (n) {
            auto i = lower(*n, key);
            if (i < n->keys.size() && equal(n->keys[i], key)) return true;
            n = n->leaf ? nullptr : n->children[i].get();
        }
        return false;
    }
    bool insert(const T& key) {
        if (contains(key)) return false;
        if (!root_) root_ = std::make_unique<Node>(true);
        if (root_->keys.size() == 2 * MinDegree - 1) {
            auto next = std::make_unique<Node>(false);
            next->children.push_back(std::move(root_)); root_ = std::move(next); split_child(*root_, 0);
        }
        insert_nonfull(*root_, key); ++size_; return true;
    }
    bool erase(const T& key) {
        if (!contains(key)) return false;
        T saved = key; // 支持 erase(min())，避免键引用在结点调整时失效。
        erase_existing(*root_, saved); --size_;
        if (root_->keys.empty()) {
            auto old = std::move(root_);
            if (!old->leaf) root_ = std::move(old->children.front());
        }
        return true;
    }
    const T& min() const {
        if (!root_) throw std::out_of_range("BTree::min");
        const Node* n = root_.get(); while (!n->leaf) n = n->children.front().get(); return n->keys.front();
    }
    const T& max() const {
        if (!root_) throw std::out_of_range("BTree::max");
        const Node* n = root_.get(); while (!n->leaf) n = n->children.back().get(); return n->keys.back();
    }
    std::vector<T> values() const { std::vector<T> out; out.reserve(size_); if (root_) traverse(*root_, out); return out; }
    bool validate() const {
        if (!root_) return size_ == 0;
        std::size_t depth = 0, count = 0;
        return check(*root_, true, nullptr, nullptr, 1, depth, count) && count == size_;
    }
    void clear() noexcept { root_.reset(); size_ = 0; }
};
} // namespace containers
