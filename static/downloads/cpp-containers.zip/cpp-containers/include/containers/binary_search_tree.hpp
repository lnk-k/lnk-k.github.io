#pragma once
#include <cstddef>
#include <functional>
#include <memory>
#include <stdexcept>
#include <utility>
#include <vector>

namespace containers {
template <typename T, typename Compare = std::less<T>>
class BinarySearchTree {
    struct Node {
        T key;
        std::unique_ptr<Node> left, right;
        explicit Node(const T& value) : key(value) {}
    };
    std::unique_ptr<Node> root_;
    std::size_t size_ = 0;
    Compare less_{};
    void traverse(const Node* n, std::vector<T>& out) const {
        if (!n) return;
        traverse(n->left.get(), out); out.push_back(n->key); traverse(n->right.get(), out);
    }
    bool check(const Node* n, const T* low, const T* high, std::size_t& count) const {
        if (!n) return true;
        if ((low && !less_(*low, n->key)) || (high && !less_(n->key, *high))) return false;
        ++count;
        return check(n->left.get(), low, &n->key, count) && check(n->right.get(), &n->key, high, count);
    }
public:
    BinarySearchTree() = default;
    BinarySearchTree(const BinarySearchTree&) = delete;
    BinarySearchTree& operator=(const BinarySearchTree&) = delete;
    bool empty() const noexcept { return size_ == 0; }
    std::size_t size() const noexcept { return size_; }
    bool contains(const T& key) const {
        const Node* p = root_.get();
        while (p) {
            if (less_(key, p->key)) p = p->left.get();
            else if (less_(p->key, key)) p = p->right.get();
            else return true;
        }
        return false;
    }
    bool insert(const T& key) {
        auto* p = &root_;
        while (*p) {
            if (less_(key, (*p)->key)) p = &(*p)->left;
            else if (less_((*p)->key, key)) p = &(*p)->right;
            else return false;
        }
        *p = std::make_unique<Node>(key); ++size_; return true;
    }
    bool erase(const T& key) {
        auto* link = &root_;
        while (*link && (less_(key, (*link)->key) || less_((*link)->key, key)))
            link = less_(key, (*link)->key) ? &(*link)->left : &(*link)->right;
        if (!*link) return false;
        auto victim = std::move(*link);
        if (!victim->left) *link = std::move(victim->right);
        else if (!victim->right) *link = std::move(victim->left);
        else {
            // 取出右子树最小结点替换待删结点，不依赖 T 的赋值操作。
            auto* successor_link = &victim->right;
            while ((*successor_link)->left) successor_link = &(*successor_link)->left;
            auto successor = std::move(*successor_link);
            *successor_link = std::move(successor->right);
            successor->left = std::move(victim->left);
            successor->right = std::move(victim->right);
            *link = std::move(successor);
        }
        --size_; return true;
    }
    const T& min() const {
        if (!root_) throw std::out_of_range("BinarySearchTree::min");
        const Node* p = root_.get(); while (p->left) p = p->left.get(); return p->key;
    }
    const T& max() const {
        if (!root_) throw std::out_of_range("BinarySearchTree::max");
        const Node* p = root_.get(); while (p->right) p = p->right.get(); return p->key;
    }
    std::vector<T> values() const { std::vector<T> out; out.reserve(size_); traverse(root_.get(), out); return out; }
    bool validate() const { std::size_t count = 0; return check(root_.get(), nullptr, nullptr, count) && count == size_; }
    // 迭代释放，避免退化成链表时析构递归导致栈溢出。
    void clear() noexcept {
        while (root_) {
            if (root_->left) {
                auto left = std::move(root_->left);
                root_->left = std::move(left->right);
                left->right = std::move(root_);
                root_ = std::move(left);
            } else {
                auto old = std::move(root_);
                root_ = std::move(old->right);
            }
        }
        size_ = 0;
    }
    ~BinarySearchTree() { clear(); }
};
} // namespace containers
