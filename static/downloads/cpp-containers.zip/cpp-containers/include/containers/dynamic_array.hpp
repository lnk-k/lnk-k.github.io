#pragma once
#include <algorithm>
#include <cstddef>
#include <memory>
#include <stdexcept>
#include <utility>

namespace containers {
// 类似 Java ArrayList；只构造实际存在的元素，不要求 T 有默认构造函数。
template <typename T>
class DynamicArray {
    using Traits = std::allocator_traits<std::allocator<T>>;
    std::allocator<T> allocator_;
    T* data_ = nullptr;
    std::size_t size_ = 0, capacity_ = 0;

public:
    DynamicArray() = default;
    DynamicArray(const DynamicArray& other) {
        reserve(other.size_);
        try {
            for (; size_ < other.size_; ++size_)
                Traits::construct(allocator_, data_ + size_, other.data_[size_]);
        } catch (...) {
            clear();
            if (data_) Traits::deallocate(allocator_, data_, capacity_);
            throw;
        }
    }
    DynamicArray(DynamicArray&& other) noexcept { swap(other); }
    DynamicArray& operator=(DynamicArray other) { swap(other); return *this; }
    ~DynamicArray() {
        clear();
        if (data_) Traits::deallocate(allocator_, data_, capacity_);
    }
    void swap(DynamicArray& other) noexcept {
        std::swap(data_, other.data_);
        std::swap(size_, other.size_);
        std::swap(capacity_, other.capacity_);
    }
    std::size_t size() const noexcept { return size_; }
    std::size_t capacity() const noexcept { return capacity_; }
    bool empty() const noexcept { return size_ == 0; }
    T& operator[](std::size_t i) noexcept { return data_[i]; }
    const T& operator[](std::size_t i) const noexcept { return data_[i]; }
    T& at(std::size_t i) {
        if (i >= size_) throw std::out_of_range("DynamicArray::at");
        return data_[i];
    }
    const T& at(std::size_t i) const {
        if (i >= size_) throw std::out_of_range("DynamicArray::at");
        return data_[i];
    }
    T& back() { return at(size_ ? size_ - 1 : 0); }
    const T& back() const { return at(size_ ? size_ - 1 : 0); }
    void reserve(std::size_t n) {
        if (n <= capacity_) return;
        if (n > Traits::max_size(allocator_)) throw std::length_error("DynamicArray too large");
        T* next = Traits::allocate(allocator_, n);
        std::size_t built = 0;
        try {
            for (; built < size_; ++built)
                Traits::construct(allocator_, next + built, std::move_if_noexcept(data_[built]));
        } catch (...) {
            for (std::size_t i = 0; i < built; ++i) Traits::destroy(allocator_, next + i);
            Traits::deallocate(allocator_, next, n);
            throw;
        }
        for (std::size_t i = 0; i < size_; ++i) Traits::destroy(allocator_, data_ + i);
        if (data_) Traits::deallocate(allocator_, data_, capacity_);
        data_ = next;
        capacity_ = n;
    }
    // 按值传参，避免 push_back(a[0]) 在扩容后引用失效。
    void push_back(T value) {
        if (size_ == capacity_) {
            const auto limit = Traits::max_size(allocator_);
            if (size_ == limit) throw std::length_error("DynamicArray too large");
            reserve(capacity_ == 0 ? 1 : (capacity_ > limit / 2 ? limit : capacity_ * 2));
        }
        Traits::construct(allocator_, data_ + size_, std::move(value));
        ++size_;
    }
    void insert(std::size_t index, T value) {
        if (index > size_) throw std::out_of_range("DynamicArray::insert");
        if (index == size_) { push_back(std::move(value)); return; }
        push_back(std::move_if_noexcept(data_[size_ - 1]));
        for (std::size_t i = size_ - 2; i > index; --i) data_[i] = std::move(data_[i - 1]);
        data_[index] = std::move(value);
    }
    void erase(std::size_t index) {
        if (index >= size_) throw std::out_of_range("DynamicArray::erase");
        for (std::size_t i = index; i + 1 < size_; ++i) data_[i] = std::move(data_[i + 1]);
        pop_back();
    }
    void pop_back() {
        if (empty()) throw std::out_of_range("DynamicArray::pop_back");
        Traits::destroy(allocator_, data_ + --size_);
    }
    void clear() noexcept {
        while (size_) Traits::destroy(allocator_, data_ + --size_);
    }
};
} // namespace containers
