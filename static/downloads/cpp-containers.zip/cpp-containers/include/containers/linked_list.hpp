#pragma once
#include <cstddef>
#include <stdexcept>
#include <utility>
#include <vector>

namespace containers {
template <typename T>
class LinkedList {
    struct Node {
        T value;
        Node* prev = nullptr;
        Node* next = nullptr;
        explicit Node(T v) : value(std::move(v)) {}
    };
    Node* head_ = nullptr;
    Node* tail_ = nullptr;
    std::size_t size_ = 0;
    Node* node_at(std::size_t i) const {
        if (i >= size_) throw std::out_of_range("LinkedList index");
        if (i < size_ / 2) {
            Node* p = head_;
            while (i--) p = p->next;
            return p;
        }
        Node* p = tail_;
        for (std::size_t j = size_ - 1; j > i; --j) p = p->prev;
        return p;
    }
public:
    LinkedList() = default;
    LinkedList(const LinkedList& other) {
        try { for (Node* p = other.head_; p; p = p->next) push_back(p->value); }
        catch (...) { clear(); throw; }
    }
    LinkedList(LinkedList&& other) noexcept { swap(other); }
    LinkedList& operator=(LinkedList other) { swap(other); return *this; }
    ~LinkedList() { clear(); }
    void swap(LinkedList& other) noexcept {
        std::swap(head_, other.head_); std::swap(tail_, other.tail_); std::swap(size_, other.size_);
    }
    std::size_t size() const noexcept { return size_; }
    bool empty() const noexcept { return size_ == 0; }
    T& at(std::size_t i) { return node_at(i)->value; }
    const T& at(std::size_t i) const { return node_at(i)->value; }
    T& front() { return at(0); }
    const T& front() const { return at(0); }
    T& back() { return at(size_ ? size_ - 1 : 0); }
    const T& back() const { return at(size_ ? size_ - 1 : 0); }
    void push_front(T value) { insert(0, std::move(value)); }
    void push_back(T value) { insert(size_, std::move(value)); }
    void insert(std::size_t index, T value) {
        if (index > size_) throw std::out_of_range("LinkedList::insert");
        Node* next = index == size_ ? nullptr : node_at(index);
        Node* prev = next ? next->prev : tail_;
        Node* p = new Node(std::move(value));
        p->prev = prev; p->next = next;
        if (prev) prev->next = p; else head_ = p;
        if (next) next->prev = p; else tail_ = p;
        ++size_;
    }
    void erase(std::size_t index) {
        Node* p = node_at(index);
        if (p->prev) p->prev->next = p->next; else head_ = p->next;
        if (p->next) p->next->prev = p->prev; else tail_ = p->prev;
        delete p; --size_;
    }
    void pop_front() { erase(0); }
    void pop_back() { erase(size_ ? size_ - 1 : 0); }
    bool remove(const T& value) {
        std::size_t i = 0;
        for (Node* p = head_; p; p = p->next, ++i)
            if (p->value == value) { erase(i); return true; }
        return false;
    }
    std::vector<T> values() const {
        std::vector<T> result; result.reserve(size_);
        for (Node* p = head_; p; p = p->next) result.push_back(p->value);
        return result;
    }
    void clear() noexcept {
        while (head_) { Node* next = head_->next; delete head_; head_ = next; }
        tail_ = nullptr; size_ = 0;
    }
};
} // namespace containers
