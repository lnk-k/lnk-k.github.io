#pragma once
#include "dynamic_array.hpp"
#include "linked_list.hpp"

namespace containers {
template <typename T>
class Stack {
    DynamicArray<T> data_;
public:
    bool empty() const noexcept { return data_.empty(); }
    std::size_t size() const noexcept { return data_.size(); }
    void push(T value) { data_.push_back(std::move(value)); }
    void pop() { data_.pop_back(); }
    T& top() { return data_.back(); }
    const T& top() const { return data_.back(); }
    void clear() noexcept { data_.clear(); }
};
template <typename T>
class Queue {
    LinkedList<T> data_;
public:
    bool empty() const noexcept { return data_.empty(); }
    std::size_t size() const noexcept { return data_.size(); }
    void enqueue(T value) { data_.push_back(std::move(value)); }
    void dequeue() { data_.pop_front(); }
    T& front() { return data_.front(); }
    const T& front() const { return data_.front(); }
    T& back() { return data_.back(); }
    const T& back() const { return data_.back(); }
    void clear() noexcept { data_.clear(); }
};
} // namespace containers
