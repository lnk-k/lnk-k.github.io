#include <iostream>
#include "containers/containers.hpp"

template <typename Range>
void print(const char* name, const Range& values) {
    std::cout << name << ": ";
    for (const auto& value : values) std::cout << value << ' ';
    std::cout << '\n';
}

int main() {
    using namespace containers;
    DynamicArray<int> array;
    array.push_back(10); array.push_back(30); array.insert(1, 20); array.erase(0);
    std::cout << "DynamicArray: ";
    for (std::size_t i = 0; i < array.size(); ++i) std::cout << array.at(i) << ' ';
    std::cout << '\n';

    LinkedList<int> list;
    list.push_back(20); list.push_front(10); list.push_back(30); list.remove(20);
    print("LinkedList", list.values());

    Stack<int> stack;
    stack.push(10); stack.push(20);
    std::cout << "Stack pop order: ";
    while (!stack.empty()) { std::cout << stack.top() << ' '; stack.pop(); }
    std::cout << '\n';

    Queue<int> queue;
    queue.enqueue(10); queue.enqueue(20);
    std::cout << "Queue dequeue order: ";
    while (!queue.empty()) { std::cout << queue.front() << ' '; queue.dequeue(); }
    std::cout << '\n';

    BinarySearchTree<int> bst;
    BTree<int, 2> btree;
    BPlusTree<int, 2> bplus;
    for (int key : {50, 20, 70, 10, 30, 60, 80, 40}) {
        bst.insert(key); btree.insert(key); bplus.insert(key);
    }
    bst.erase(50); btree.erase(50); bplus.erase(50);
    print("BST", bst.values());
    print("BTree", btree.values());
    print("BPlusTree", bplus.values());
    print("BPlusTree range [25, 65]", bplus.range_query(25, 65));
    std::cout << std::boolalpha << "All trees valid: " << (bst.validate() && btree.validate() && bplus.validate()) << '\n';
}
