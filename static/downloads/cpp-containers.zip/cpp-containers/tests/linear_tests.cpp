#include <gtest/gtest.h>
#include <deque>
#include <memory>
#include <random>
#include <string>
#include <vector>
#include "containers/containers.hpp"

using namespace containers;

TEST(DynamicArrayTest, BoundariesAndGrowth) {
    DynamicArray<int> a;
    EXPECT_TRUE(a.empty());
    EXPECT_EQ(a.capacity(), 0u);
    EXPECT_THROW(a.at(0), std::out_of_range);
    EXPECT_THROW(a.pop_back(), std::out_of_range);
    EXPECT_THROW(a.insert(1, 9), std::out_of_range);
    EXPECT_THROW(a.erase(0), std::out_of_range);
    for (int i = 0; i < 1024; ++i) a.push_back(i);
    EXPECT_EQ(a.size(), 1024u);
    EXPECT_GE(a.capacity(), a.size());
    for (int i = 0; i < 1024; ++i) EXPECT_EQ(a.at(i), i);
    auto capacity = a.capacity(); a.reserve(1);
    EXPECT_EQ(a.capacity(), capacity);
    a.reserve(2048);
    EXPECT_GE(a.capacity(), 2048u);
    a.clear();
    EXPECT_TRUE(a.empty());
    EXPECT_GE(a.capacity(), 2048u);
    a.insert(0, 7);
    EXPECT_EQ(a.back(), 7);
}

TEST(DynamicArrayTest, InsertEraseCopyMoveAndAliasing) {
    DynamicArray<std::string> a;
    a.push_back("a"); a.push_back(a[0]); a.insert(1, "b");
    EXPECT_EQ(a.at(0), "a");
    EXPECT_EQ(a.at(1), "b");
    EXPECT_EQ(a.at(2), "a");
    a.erase(1);
    EXPECT_EQ(a.size(), 2u);
    EXPECT_EQ(a.at(1), "a");
    a.insert(0, a.back());
    EXPECT_EQ(a.at(0), "a");
    auto copied = a; copied.at(0) = "changed";
    EXPECT_EQ(a.at(0), "a");
    DynamicArray<std::string> assigned; assigned = copied;
    EXPECT_EQ(assigned.at(0), "changed");
    DynamicArray<std::string> moved(std::move(copied));
    EXPECT_TRUE(copied.empty());
    EXPECT_EQ(moved.at(0), "changed");
    assigned = std::move(moved);
    EXPECT_TRUE(moved.empty());
    const auto& const_array = assigned;
    EXPECT_EQ(const_array.back(), "a");
    EXPECT_EQ(const_array[0], "changed");
    EXPECT_THROW(const_array.at(assigned.size()), std::out_of_range);
}

TEST(DynamicArrayTest, MoveOnlyElements) {
    DynamicArray<std::unique_ptr<int>> a;
    a.push_back(std::make_unique<int>(1)); a.push_back(std::make_unique<int>(3));
    a.insert(1, std::make_unique<int>(2));
    ASSERT_EQ(a.size(), 3u);
    for (std::size_t i = 0; i < 3; ++i) ASSERT_EQ(*a.at(i), static_cast<int>(i + 1));
    a.erase(0);
    EXPECT_EQ(*a.at(0), 2);
}

struct Lifetime {
    inline static int alive = 0;
    int value;
    explicit Lifetime(int v) : value(v) { ++alive; }
    Lifetime(const Lifetime& o) : value(o.value) { ++alive; }
    Lifetime(Lifetime&& o) noexcept : value(o.value) { ++alive; }
    Lifetime& operator=(const Lifetime&) = default;
    Lifetime& operator=(Lifetime&&) = default;
    ~Lifetime() { --alive; }
};

TEST(LinearStorageTest, ElementLifetimes) {
    EXPECT_EQ(Lifetime::alive, 0);
    {
        DynamicArray<Lifetime> a;
        for (int i = 0; i < 100; ++i) a.push_back(Lifetime(i));
        EXPECT_EQ(Lifetime::alive, 100);
        a.reserve(500);
    EXPECT_EQ(Lifetime::alive, 100);
        a.pop_back();
    EXPECT_EQ(Lifetime::alive, 99);
        auto copy = a;
    EXPECT_EQ(Lifetime::alive, 198);
        a.clear();
    EXPECT_EQ(Lifetime::alive, 99);
    }
    EXPECT_EQ(Lifetime::alive, 0);
    {
        LinkedList<Lifetime> list;
        list.push_back(Lifetime(1)); list.push_front(Lifetime(2));
        auto copy = list;
    EXPECT_EQ(Lifetime::alive, 4);
        copy.pop_front();
    EXPECT_EQ(Lifetime::alive, 3);
    }
    EXPECT_EQ(Lifetime::alive, 0);
}

TEST(DynamicArrayTest, RandomizedAgainstVector) {
    std::mt19937 rng(20260922);
    DynamicArray<int> a; std::vector<int> expected;
    for (int step = 0; step < 4000; ++step) {
        SCOPED_TRACE(step);
        const auto op = rng() % 3;
        if (expected.empty() || op == 0) {
            auto i = rng() % (expected.size() + 1); int value = static_cast<int>(rng() % 1000);
            a.insert(i, value); expected.insert(expected.begin() + i, value);
        } else if (op == 1) {
            auto i = rng() % expected.size(); a.erase(i); expected.erase(expected.begin() + i);
        } else {
            auto i = rng() % expected.size(); a.at(i) = expected[i] = static_cast<int>(rng() % 1000);
        }
        ASSERT_EQ(a.size(), expected.size());
        for (std::size_t i = 0; i < expected.size(); ++i) ASSERT_EQ(a.at(i), expected[i]);
    }
}

TEST(LinkedListTest, BoundariesCopyMoveAndRemove) {
    LinkedList<std::string> list;
    EXPECT_THROW(list.front(), std::out_of_range);
    EXPECT_THROW(list.back(), std::out_of_range);
    EXPECT_THROW(list.pop_front(), std::out_of_range);
    EXPECT_THROW(list.pop_back(), std::out_of_range);
    EXPECT_THROW(list.insert(1, "x"), std::out_of_range);
    EXPECT_FALSE(list.remove("x"));
    list.push_back("b"); list.push_front("a"); list.push_back("d"); list.insert(2, "c");
    EXPECT_EQ(list.values(), (std::vector<std::string>{"a", "b", "c", "d"}));
    EXPECT_TRUE(list.remove("b"));
    EXPECT_FALSE(list.remove("missing"));
    list.push_back("a"); list.remove("a");
    EXPECT_EQ(list.back(), "a");
    auto copy = list; copy.front() = "changed";
    EXPECT_EQ(list.front(), "c");
    LinkedList<std::string> assigned; assigned = copy;
    LinkedList<std::string> moved(std::move(copy));
    EXPECT_TRUE(copy.empty());
    assigned = std::move(moved);
    EXPECT_TRUE(moved.empty());
    const auto& c = assigned;
    EXPECT_EQ(c.front(), "changed");
    EXPECT_EQ(c.back(), "a");
    assigned.pop_back(); assigned.pop_front(); assigned.pop_front();
    EXPECT_TRUE(assigned.empty());
    assigned.push_front("reuse"); assigned.clear();
    EXPECT_TRUE(assigned.empty());
}

TEST(LinkedListTest, RandomizedAgainstVector) {
    std::mt19937 rng(20260923); LinkedList<int> list; std::vector<int> expected;
    for (int step = 0; step < 4000; ++step) {
        SCOPED_TRACE(step);
        if (expected.empty() || rng() % 2) {
            auto i = rng() % (expected.size() + 1); int value = static_cast<int>(rng() % 1000);
            list.insert(i, value); expected.insert(expected.begin() + i, value);
        } else {
            auto i = rng() % expected.size(); list.erase(i); expected.erase(expected.begin() + i);
        }
        ASSERT_EQ(list.size(), expected.size()); ASSERT_EQ(list.values(), expected);
        for (std::size_t i = 0; i < expected.size(); ++i) ASSERT_EQ(list.at(i), expected[i]);
    }
}

TEST(StackTest, LifoAndEmptyErrors) {
    Stack<int> s;
    EXPECT_THROW(s.top(), std::out_of_range);
    EXPECT_THROW(s.pop(), std::out_of_range);
    for (int i = 0; i < 100; ++i) s.push(i);
    auto copy = s; copy.pop();
    EXPECT_EQ(s.size(), 100u);
    const auto& c = s;
    EXPECT_EQ(c.top(), 99);
    for (int i = 99; i >= 0; --i) { EXPECT_EQ(s.top(), i); s.pop(); }
    EXPECT_TRUE(s.empty()); s.push(5); s.clear();
    EXPECT_TRUE(s.empty());
}

TEST(QueueTest, FifoAndEmptyErrors) {
    Queue<int> q;
    EXPECT_THROW(q.front(), std::out_of_range);
    EXPECT_THROW(q.back(), std::out_of_range);
    EXPECT_THROW(q.dequeue(), std::out_of_range);
    for (int i = 0; i < 100; ++i) q.enqueue(i);
    auto copy = q; copy.dequeue();
    EXPECT_EQ(q.size(), 100u);
    const auto& c = q;
    EXPECT_EQ(c.front(), 0);
    EXPECT_EQ(c.back(), 99);
    for (int i = 0; i < 100; ++i) { EXPECT_EQ(q.front(), i); q.dequeue(); }
    EXPECT_TRUE(q.empty()); q.enqueue(5); q.clear();
    EXPECT_TRUE(q.empty());
}

TEST(StackQueueTest, RandomizedAgainstDeque) {
    std::mt19937 rng(20260924); Stack<int> s; Queue<int> q; std::deque<int> stack_ref, queue_ref;
    for (int step = 0; step < 5000; ++step) {
        SCOPED_TRACE(step);
        if (stack_ref.empty() || rng() % 2) {
            int x = static_cast<int>(rng() % 1000); s.push(x); q.enqueue(x);
            stack_ref.push_back(x); queue_ref.push_back(x);
        } else {
            ASSERT_EQ(s.top(), stack_ref.back()); ASSERT_EQ(q.front(), queue_ref.front());
            s.pop(); q.dequeue(); stack_ref.pop_back(); queue_ref.pop_front();
        }
        ASSERT_EQ(s.size(), stack_ref.size()); ASSERT_EQ(q.size(), queue_ref.size());
        if (!queue_ref.empty()) ASSERT_EQ(q.back(), queue_ref.back());
    }
}
