#include <gtest/gtest.h>
#include <algorithm>
#include <functional>
#include <numeric>
#include <random>
#include <set>
#include <string>
#include <vector>
#include "containers/containers.hpp"

using namespace containers;
struct TypeNames {
    template <typename T> static std::string GetName(int index) {
        return "Config" + std::to_string(index);
    }
};
template <typename T> class OrderedTreeTest : public ::testing::Test {};
using TreeTypes = ::testing::Types<BinarySearchTree<int>, BTree<int, 2>, BTree<int, 3>, BTree<int, 8>,
                                  BPlusTree<int, 2>, BPlusTree<int, 3>, BPlusTree<int, 8>>;
TYPED_TEST_SUITE(OrderedTreeTest, TreeTypes, TypeNames);

TYPED_TEST(OrderedTreeTest, EmptyAndDuplicateKeys) {
    TypeParam tree;
    EXPECT_TRUE(tree.empty());
    EXPECT_TRUE(tree.validate());
    EXPECT_TRUE(tree.values().empty());
    EXPECT_FALSE(tree.contains(7));
    EXPECT_FALSE(tree.erase(7));
    EXPECT_THROW(tree.min(), std::out_of_range);
    EXPECT_THROW(tree.max(), std::out_of_range);
    EXPECT_TRUE(tree.insert(7));
    EXPECT_FALSE(tree.insert(7));
    EXPECT_EQ(tree.size(), 1u);
    EXPECT_EQ(tree.min(), 7);
    EXPECT_EQ(tree.max(), 7);
    EXPECT_TRUE(tree.contains(7));
    EXPECT_TRUE(tree.erase(7));
    EXPECT_FALSE(tree.erase(7));
    EXPECT_TRUE(tree.empty());
    EXPECT_TRUE(tree.validate());
}

TYPED_TEST(OrderedTreeTest, BasicDeletionShapesAndClear) {
    TypeParam tree;
    for (int x : {50, 20, 70, 10, 30, 60, 80, 25, 65}) ASSERT_TRUE(tree.insert(x));
    // 叶结点、单子结点、双子结点、根及不存在的键。
    for (int x : {10, 60, 20, 50}) { ASSERT_TRUE(tree.erase(x)); ASSERT_TRUE(tree.validate()); }
    EXPECT_FALSE(tree.erase(999));
    EXPECT_EQ(tree.values(), (std::vector<int>{25, 30, 65, 70, 80}));
    EXPECT_EQ(tree.min(), 25);
    EXPECT_EQ(tree.max(), 80);
    tree.clear();
    EXPECT_TRUE(tree.empty());
    EXPECT_TRUE(tree.validate());
    tree.insert(-1);
    EXPECT_EQ(tree.values(), (std::vector<int>{-1}));
}

TYPED_TEST(OrderedTreeTest, SplitBorrowMergeAndRootShrink) {
    for (int order = 0; order < 3; ++order) {
        SCOPED_TRACE(order);
        TypeParam tree; std::set<int> expected;
        std::vector<int> keys(300); std::iota(keys.begin(), keys.end(), 0);
        for (int x : keys) { ASSERT_TRUE(tree.insert(x)); expected.insert(x); ASSERT_TRUE(tree.validate()); }
        if (order == 1) std::reverse(keys.begin(), keys.end());
        if (order == 2) { std::mt19937 rng(314159); std::shuffle(keys.begin(), keys.end(), rng); }
        for (int x : keys) {
            SCOPED_TRACE(x);
            ASSERT_TRUE(tree.erase(x)); expected.erase(x);
            ASSERT_TRUE(tree.validate()); ASSERT_EQ(tree.size(), expected.size());
            ASSERT_EQ(tree.values(), (std::vector<int>(expected.begin(), expected.end())));
        }
        ASSERT_TRUE(tree.empty()); tree.insert(42); ASSERT_TRUE(tree.validate());
    }
}

TYPED_TEST(OrderedTreeTest, RandomizedAgainstSet) {
    for (unsigned seed : {42u, 20260922u, 8675309u}) {
        SCOPED_TRACE(seed);
        std::mt19937 rng(seed); TypeParam tree; std::set<int> expected;
        for (int step = 0; step < 3000; ++step) {
            SCOPED_TRACE(step);
            int key = static_cast<int>(rng() % 1001) - 500;
            switch (rng() % 3) {
            case 0: ASSERT_EQ(tree.insert(key), expected.insert(key).second); break;
            case 1: ASSERT_EQ(tree.erase(key), expected.erase(key) != 0); break;
            default: ASSERT_EQ(tree.contains(key), expected.count(key) != 0); break;
            }
            ASSERT_TRUE(tree.validate()); ASSERT_EQ(tree.size(), expected.size());
            ASSERT_EQ(tree.values(), (std::vector<int>(expected.begin(), expected.end())));
            if (!expected.empty()) { ASSERT_EQ(tree.min(), *expected.begin()); ASSERT_EQ(tree.max(), *expected.rbegin()); }
        }
    }
}

TYPED_TEST(OrderedTreeTest, EraseUsingReferenceToMinimum) {
    TypeParam tree;
    for (int i = 0; i < 100; ++i) tree.insert(i);
    while (!tree.empty()) { ASSERT_TRUE(tree.erase(tree.min())); ASSERT_TRUE(tree.validate()); }
}

template <typename T> class BPlusRangeTest : public ::testing::Test {};
using BPlusTypes = ::testing::Types<BPlusTree<int, 2>, BPlusTree<int, 3>, BPlusTree<int, 8>>;
TYPED_TEST_SUITE(BPlusRangeTest, BPlusTypes, TypeNames);

TYPED_TEST(BPlusRangeTest, InclusiveBoundsAndMultipleLeaves) {
    TypeParam tree;
    EXPECT_TRUE(tree.range_query(0, 10).empty());
    for (int i = 0; i < 100; i += 2) tree.insert(i);
    EXPECT_EQ(tree.range_query(7, 16), (std::vector<int>{8, 10, 12, 14, 16}));
    EXPECT_EQ(tree.range_query(8, 8), (std::vector<int>{8}));
    EXPECT_TRUE(tree.range_query(9, 9).empty());
    EXPECT_TRUE(tree.range_query(20, 10).empty());
    EXPECT_TRUE(tree.range_query(-10, -1).empty());
    EXPECT_TRUE(tree.range_query(100, 200).empty());
    EXPECT_EQ(tree.range_query(-100, 200), tree.values());
    for (int i = 0; i < 80; i += 2) { tree.erase(i); ASSERT_TRUE(tree.validate()); }
    EXPECT_EQ(tree.range_query(75, 88), (std::vector<int>{80, 82, 84, 86, 88}));
}

TYPED_TEST(BPlusRangeTest, RandomizedRangesAfterMutations) {
    TypeParam tree; std::set<int> expected; std::mt19937 rng(271828);
    for (int step = 0; step < 4000; ++step) {
        SCOPED_TRACE(step); int key = static_cast<int>(rng() % 500);
        if (rng() % 2) { tree.insert(key); expected.insert(key); }
        else { tree.erase(key); expected.erase(key); }
        int low = static_cast<int>(rng() % 600) - 50, high = static_cast<int>(rng() % 600) - 50;
        if (low > high) std::swap(low, high);
        std::vector<int> wanted(expected.lower_bound(low), expected.upper_bound(high));
        ASSERT_EQ(tree.range_query(low, high), wanted); ASSERT_TRUE(tree.validate());
    }
}

template <typename Tree> void check_strings() {
    Tree tree;
    for (const auto* s : {"pear", "apple", "orange", "banana", "peach", "plum"}) tree.insert(s);
    tree.erase("orange");
    EXPECT_TRUE(tree.contains("banana"));
    EXPECT_EQ(tree.values(), (std::vector<std::string>{"apple", "banana", "peach", "pear", "plum"}));
    EXPECT_TRUE(tree.validate());
}
TEST(TreeGenericTest, StringKeys) {
    check_strings<BinarySearchTree<std::string>>(); check_strings<BTree<std::string, 2>>(); check_strings<BPlusTree<std::string, 2>>();
}
template <typename Tree> void check_descending() {
    Tree tree; std::set<int, std::greater<int>> ref;
    for (int i = 0; i < 100; ++i) { tree.insert(i); ref.insert(i); }
    for (int i = 0; i < 100; i += 3) { tree.erase(i); ref.erase(i); ASSERT_TRUE(tree.validate()); }
    EXPECT_EQ(tree.values(), (std::vector<int>(ref.begin(), ref.end())));
    EXPECT_EQ(tree.min(), *ref.begin());
    EXPECT_EQ(tree.max(), *ref.rbegin());
}
TEST(TreeGenericTest, CustomComparator) {
    check_descending<BinarySearchTree<int, std::greater<int>>>();
    check_descending<BTree<int, 2, std::greater<int>>>();
    check_descending<BPlusTree<int, 2, std::greater<int>>>();
    BPlusTree<int, 2, std::greater<int>> tree;
    for (int i = 0; i < 20; ++i) tree.insert(i);
    EXPECT_EQ(tree.range_query(10, 5), (std::vector<int>{10, 9, 8, 7, 6, 5}));
    EXPECT_TRUE(tree.range_query(5, 10).empty());
}
